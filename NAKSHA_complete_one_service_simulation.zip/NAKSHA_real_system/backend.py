from __future__ import annotations

import datetime as dt
import json
import math
import os
import re
import uuid
import zipfile
from difflib import SequenceMatcher
from pathlib import Path
from typing import Any

import geopandas as gpd
import pandas as pd
from fastapi import FastAPI, File, HTTPException, UploadFile
from fastapi.responses import FileResponse
from fastapi.staticfiles import StaticFiles
from fastapi.middleware.cors import CORSMiddleware
from pyproj import CRS, Transformer
from shapely.geometry import mapping, shape
from shapely.ops import unary_union
from shapely.validation import explain_validity
from shapely import make_valid

try:
    import rasterio
except ImportError:  # pragma: no cover
    rasterio = None

try:
    from sqlalchemy import create_engine, text
except ImportError:  # pragma: no cover
    create_engine = None
    text = None

APP_TITLE = "NAKSHA Geospatial Harmonization API"
DATA_DIR = Path(os.getenv("NAKSHA_DATA_DIR", str(Path(__file__).resolve().parent / "data"))).resolve()
DATA_DIR.mkdir(parents=True, exist_ok=True)
POSTGIS_URL = os.getenv("NAKSHA_POSTGIS_URL", "")
MAX_UPLOAD_MB = int(os.getenv("NAKSHA_MAX_UPLOAD_MB", "512"))

app = FastAPI(title=APP_TITLE, version="2.0.0")
APP_DIR = Path(__file__).resolve().parent
FRONTEND_FILE = APP_DIR / "index.html"
app.add_middleware(
    CORSMiddleware,
    allow_origins=[x.strip() for x in os.getenv("NAKSHA_CORS", "*").split(",")],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Same-origin frontend: one FastAPI service hosts both UI and API.
@app.get("/", include_in_schema=False)
def frontend():
    if not FRONTEND_FILE.exists():
        raise HTTPException(404, "Frontend not found")
    return FileResponse(FRONTEND_FILE)

AUDIT: list[dict[str, Any]] = []

VECTOR_EXTS = {".shp", ".gpkg", ".geojson", ".json", ".kml", ".zip"}
RASTER_EXTS = {".tif", ".tiff", ".img", ".ori"}
TABLE_EXTS = {".csv", ".xlsx", ".xls"}

ALIASES = {
    "parcel_id": ["parcel_id", "parcelid", "plot_id", "plotno", "plot_no", "khasra_no", "khasra", "survey_no", "survey_number", "property_id"],
    "owner_name": ["owner_name", "owner", "ownername", "khatedar_name", "khatedar", "name", "proprietor"],
    "address_id": ["address_id", "address", "house_no", "house_number", "property_address"],
    "area_sq_m": ["area_sq_m", "area_m2", "area", "area_sqm", "area_square_meters", "area_sqmt"],
}


def audit(action: str, obj: str, result: str, **extra: Any) -> None:
    AUDIT.append({
        "timestamp": dt.datetime.now(dt.timezone.utc).isoformat(),
        "actor": "NAKSHA API",
        "action": action,
        "object": obj,
        "result": result,
        **extra,
    })


def safe_path(raw: str) -> Path:
    p = Path(raw).expanduser().resolve()
    if DATA_DIR not in p.parents and p != DATA_DIR:
        raise HTTPException(400, "Path outside NAKSHA data directory")
    if not p.exists():
        raise HTTPException(404, f"File not found: {p.name}")
    return p


def jsonable(value: Any) -> Any:
    if isinstance(value, dict):
        return {str(k): jsonable(v) for k, v in value.items()}
    if isinstance(value, (list, tuple)):
        return [jsonable(v) for v in value]
    if hasattr(value, "item"):
        try:
            return value.item()
        except Exception:
            pass
    if isinstance(value, (dt.datetime, dt.date)):
        return value.isoformat()
    if isinstance(value, float) and (math.isnan(value) or math.isinf(value)):
        return None
    return value


def inspect_vector(path: Path) -> dict[str, Any]:
    try:
        layers = None
        if path.suffix.lower() in {".gpkg", ".zip"}:
            try:
                layers = gpd.list_layers(path)
            except Exception:
                layers = None
        layer_names = []
        if layers is not None:
            try:
                layer_names = [str(x) for x in layers["name"].tolist()]
            except Exception:
                layer_names = []
        layer_name = layer_names[0] if layer_names else None
        gdf = gpd.read_file(path, layer=layer_name) if layer_name else gpd.read_file(path)
        return {
            "kind": "vector",
            "crs": gdf.crs.to_string() if gdf.crs else None,
            "feature_count": int(len(gdf)),
            "columns": [str(c) for c in gdf.columns if c != gdf.geometry.name],
            "geometry_types": {str(k): int(v) for k, v in gdf.geometry.geom_type.value_counts().items()},
            "bounds": [float(x) for x in gdf.total_bounds] if len(gdf) else None,
            "layers": layer_names,
        }
    except Exception as exc:
        raise HTTPException(400, f"Vector read failed: {exc}") from exc


def inspect_raster(path: Path) -> dict[str, Any]:
    if rasterio is None:
        raise HTTPException(500, "rasterio is not installed")
    try:
        with rasterio.open(path) as ds:
            return {
                "kind": "raster",
                "driver": ds.driver,
                "crs": ds.crs.to_string() if ds.crs else None,
                "width": int(ds.width),
                "height": int(ds.height),
                "count": int(ds.count),
                "dtype": str(ds.dtypes[0]) if ds.count else None,
                "bounds": [float(x) for x in ds.bounds],
                "resolution": [float(x) for x in ds.res],
                "nodata": jsonable(ds.nodata),
                "transform": [float(x) for x in ds.transform[:6]],
                "tags": jsonable(ds.tags()),
            }
    except Exception as exc:
        raise HTTPException(400, f"Raster read failed: {exc}") from exc


def inspect_table(path: Path) -> dict[str, Any]:
    try:
        if path.suffix.lower() == ".csv":
            df = pd.read_csv(path, nrows=50)
        else:
            df = pd.read_excel(path, nrows=50)
        return {
            "kind": "table",
            "columns": [str(c) for c in df.columns],
            "row_count_sample": int(len(df)),
            "sample_rows": jsonable(df.head(5).to_dict(orient="records")),
        }
    except Exception as exc:
        raise HTTPException(400, f"Tabular read failed: {exc}") from exc


def inspect_file(path: Path) -> dict[str, Any]:
    ext = path.suffix.lower()
    if ext in VECTOR_EXTS:
        return inspect_vector(path)
    if ext in RASTER_EXTS:
        return inspect_raster(path)
    if ext in TABLE_EXTS:
        return inspect_table(path)
    raise HTTPException(400, f"Unsupported extension: {ext}")


def read_vector(path: Path, layer: str | None = None) -> gpd.GeoDataFrame:
    try:
        return gpd.read_file(path, layer=layer) if layer else gpd.read_file(path)
    except Exception as exc:
        raise HTTPException(400, f"Could not open vector layer: {exc}") from exc


def metric_pair(gdf: gpd.GeoDataFrame) -> gpd.GeoDataFrame:
    if gdf.crs is None:
        raise HTTPException(400, "Vector has no CRS; assign a CRS before matching")
    crs = CRS.from_user_input(gdf.crs)
    if not crs.is_projected:
        try:
            target = gdf.estimate_utm_crs()
        except Exception:
            target = None
        if target is None:
            raise HTTPException(400, "Unable to determine a metric projected CRS")
        return gdf.to_crs(target)
    return gdf


def normalized_text(value: Any) -> str:
    return re.sub(r"[^a-z0-9]+", "", str(value or "").lower())


def attribute_similarity(a: pd.Series, b: pd.Series) -> float:
    amap = {normalized_text(k): normalized_text(v) for k, v in a.to_dict().items() if str(k).lower() != "geometry"}
    bmap = {normalized_text(k): normalized_text(v) for k, v in b.to_dict().items() if str(k).lower() != "geometry"}
    if not amap or not bmap:
        return 0.0
    scores = []
    for ak, av in amap.items():
        for bk, bv in bmap.items():
            if ak == bk and av and bv:
                scores.append(1.0 if av == bv else SequenceMatcher(None, av, bv).ratio())
    return max(scores) if scores else 0.0


def pair_match(g1: gpd.GeoDataFrame, g2: gpd.GeoDataFrame, max_candidates: int = 500) -> list[dict[str, Any]]:
    a = metric_pair(g1.copy())
    b = metric_pair(g2.copy())
    if len(a) > max_candidates or len(b) > max_candidates:
        a, b = a.head(max_candidates), b.head(max_candidates)
    rows = []
    for i, ra in a.iterrows():
        ga = ra.geometry
        if ga is None or ga.is_empty:
            continue
        for j, rb in b.iterrows():
            gb = rb.geometry
            if gb is None or gb.is_empty:
                continue
            minx, miny, maxx, maxy = ga.bounds
            bx0, by0, bx1, by1 = gb.bounds
            # cheap proximity filter: expanded bbox based on max parcel dimension
            pad = max(maxx - minx, maxy - miny, 10.0) * 1.25
            if bx1 < minx - pad or bx0 > maxx + pad or by1 < miny - pad or by0 > maxy + pad:
                continue
            inter = ga.intersection(gb).area
            union = ga.union(gb).area
            iou = inter / union if union else 0.0
            dist = float(ga.centroid.distance(gb.centroid))
            denom = max(math.sqrt(max(ga.area, 1e-9)) + math.sqrt(max(gb.area, 1e-9)), 1.0)
            distance_sim = max(0.0, 1.0 - dist / denom)
            area_sim = min(ga.area, gb.area) / max(ga.area, gb.area) if max(ga.area, gb.area) else 0.0
            attr = attribute_similarity(ra, rb)
            score = 0.40 * iou + 0.25 * distance_sim + 0.20 * area_sim + 0.15 * attr
            if score >= 0.90:
                decision = "Auto-accept"
            elif score >= 0.60:
                decision = "Review"
            else:
                decision = "Conflict"
            rows.append({
                "a_index": int(i), "b_index": int(j),
                "iou": round(iou, 4), "distance_m": round(dist, 3),
                "area_similarity": round(area_sim, 4), "attribute_similarity": round(attr, 4),
                "confidence": round(score * 100, 1), "decision": decision,
            })
    rows.sort(key=lambda x: x["confidence"], reverse=True)
    return rows[:250]


def topology_report(gdf: gpd.GeoDataFrame) -> dict[str, Any]:
    geoms = [g for g in gdf.geometry if g is not None]
    invalid = [i for i, g in enumerate(gdf.geometry) if g is not None and not g.is_valid]
    overlaps = []
    for idx, ga in enumerate(geoms):
        for jdx in range(idx + 1, len(geoms)):
            gb = geoms[jdx]
            if not ga.is_empty and ga.intersects(gb):
                inter = ga.intersection(gb).area
                if inter > max(1e-9, min(ga.area, gb.area) * 0.0001):
                    overlaps.append([idx, jdx])
    areas = [g.area for g in geoms if not g.is_empty]
    tiny = sum(1 for a in areas if areas and a < max(sum(areas) / max(len(areas), 1) * 0.001, 1e-9))
    return {
        "feature_count": len(gdf),
        "valid_count": len(gdf) - len(invalid),
        "valid_pct": round((len(gdf) - len(invalid)) / len(gdf) * 100, 2) if len(gdf) else 100,
        "invalid_geometries": invalid,
        "invalid_count": len(invalid),
        "overlap_pairs": overlaps[:250],
        "overlap_count": len(overlaps),
        "gap_sliver_count": tiny,
        "invalid_reasons": {str(i): explain_validity(gdf.geometry.iloc[i]) for i in invalid[:50]},
    }


@app.get("/api/demo-workspace")
def demo_workspace():
    sim = DATA_DIR / "simulation"
    manifest = sim / "manifest.json"
    if not manifest.exists():
        raise HTTPException(404, "Simulation dataset package not installed")
    files = json.loads(manifest.read_text()).get("datasets", [])
    out = []
    for name in files:
        path = sim / name
        if path.exists() and path.is_file():
            meta = {"name": name, "path": str(path), "type": path.suffix.lower().lstrip(".")}
            try:
                meta.update(inspect_file(path))
            except Exception as exc:
                meta["error"] = str(exc)
            out.append(meta)
    audit("DEMO_WORKSPACE", "simulation", "Loaded", datasets=len(out))
    return {"ok": True, "synthetic": True, "warning": "Synthetic demo data only — not official land records.", "datasets": out}


@app.get("/api/health")
def health():
    return {
        "ok": True,
        "engine": "GDAL/OGR + PROJ + GeoPandas/Pyogrio + Shapely + Rasterio",
        "postgis_configured": bool(POSTGIS_URL),
        "timestamp": dt.datetime.now(dt.timezone.utc).isoformat(),
    }


@app.post("/api/upload")
async def upload(file: UploadFile = File(...)):
    name = Path(file.filename or "upload.bin").name
    ext = Path(name).suffix.lower()
    if ext not in VECTOR_EXTS | RASTER_EXTS | TABLE_EXTS:
        raise HTTPException(400, f"Unsupported extension: {ext}")
    content = await file.read()
    if len(content) > MAX_UPLOAD_MB * 1024 * 1024:
        raise HTTPException(413, f"Upload exceeds {MAX_UPLOAD_MB} MB")
    path = DATA_DIR / f"{uuid.uuid4().hex}_{name}"
    path.write_bytes(content)
    meta = inspect_file(path)
    audit("UPLOAD", name, "Inspected", path=str(path), kind=meta.get("kind"))
    return {"path": str(path), "filename": name, **meta}


@app.get("/api/inspect")
def inspect(path: str):
    return inspect_file(safe_path(path))


@app.post("/api/transform")
def transform(payload: dict[str, Any]):
    source_crs = payload.get("source_crs")
    target_crs = payload.get("target_crs")
    coordinates = payload.get("coordinates", [])
    if not source_crs or not target_crs:
        raise HTTPException(422, "source_crs and target_crs are required")
    transformer = Transformer.from_crs(source_crs, target_crs, always_xy=True)
    out = [list(transformer.transform(float(x), float(y))) for x, y in coordinates]
    audit("TRANSFORM", f"{source_crs}->{target_crs}", "Completed", count=len(out))
    return {"source_crs": source_crs, "target_crs": target_crs, "coordinates": out}


@app.post("/api/match")
def match(payload: dict[str, Any]):
    a = safe_path(str(payload.get("source_a", "")))
    b = safe_path(str(payload.get("source_b", "")))
    g1 = read_vector(a, payload.get("layer_a"))
    g2 = read_vector(b, payload.get("layer_b"))
    rows = pair_match(g1, g2, int(payload.get("max_candidates", 500)))
    audit("MATCH", f"{a.name} ↔ {b.name}", "Completed", matches=len(rows))
    return {"ok": True, "matches": rows, "weights": {"iou": .40, "distance": .25, "area": .20, "attributes": .15}}


@app.post("/api/topology/scan")
def topology_scan(payload: dict[str, Any]):
    gdf = read_vector(safe_path(str(payload.get("source", ""))), payload.get("layer"))
    report = topology_report(gdf)
    audit("TOPOLOGY_SCAN", Path(str(payload.get("source", ""))).name, "Completed", invalid=report["invalid_count"], overlaps=report["overlap_count"])
    return {"ok": True, **report}


@app.post("/api/topology/repair")
def topology_repair(payload: dict[str, Any]):
    path = safe_path(str(payload.get("source", "")))
    gdf = read_vector(path, payload.get("layer"))
    original = topology_report(gdf)
    repaired = gdf.copy()
    repaired[repaired.geometry.name] = repaired.geometry.map(lambda g: make_valid(g) if g is not None and not g.is_valid else g)
    out = DATA_DIR / f"{uuid.uuid4().hex}_repaired.gpkg"
    repaired.to_file(out, layer="harmonized", driver="GPKG")
    after = topology_report(repaired)
    audit("TOPOLOGY_REPAIR", path.name, "Completed", before=original["invalid_count"], after=after["invalid_count"])
    return {"ok": True, "output": str(out), "before": original, "after": after}


def detect_fields(columns: list[str]) -> dict[str, dict[str, Any]]:
    result = {}
    for target, aliases in ALIASES.items():
        best = (None, 0.0)
        for col in columns:
            cn = normalized_text(col)
            for alias in aliases:
                score = 1.0 if cn == normalized_text(alias) else SequenceMatcher(None, cn, normalized_text(alias)).ratio()
                if score > best[1]:
                    best = (col, score)
        result[target] = {"source_field": best[0], "confidence": round(best[1] * 100, 1) if best[0] else 0}
    return result


@app.post("/api/records/map-schema")
def map_schema(payload: dict[str, Any]):
    path = safe_path(str(payload.get("source", "")))
    meta = inspect_table(path)
    fields = detect_fields(meta["columns"])
    audit("SCHEMA_MAP", path.name, "Completed")
    return {"ok": True, "mapping": fields, "columns": meta["columns"]}


@app.post("/api/records/link")
def link_records(payload: dict[str, Any]):
    vector_path = safe_path(str(payload.get("vector", "")))
    table_path = safe_path(str(payload.get("table", "")))
    gdf = read_vector(vector_path, payload.get("layer"))
    if table_path.suffix.lower() == ".csv":
        df = pd.read_csv(table_path)
    else:
        df = pd.read_excel(table_path)
    mapping_fields = detect_fields([str(c) for c in df.columns])
    parcel_field = mapping_fields["parcel_id"]["source_field"]
    owner_field = mapping_fields["owner_name"]["source_field"]
    if not parcel_field:
        raise HTTPException(400, "No parcel identifier field could be mapped")
    candidate_cols = [c for c in gdf.columns if c != gdf.geometry.name]
    g_parcel = next((c for c in candidate_cols if normalized_text(c) in {normalized_text(x) for x in ALIASES["parcel_id"]}), None)
    results = []
    for idx, row in gdf.head(1000).iterrows():
        gp = normalized_text(row[g_parcel]) if g_parcel else ""
        best = None
        for ridx, r in df.head(5000).iterrows():
            tp = normalized_text(r[parcel_field])
            score = 100.0 if gp and tp and gp == tp else (SequenceMatcher(None, gp, tp).ratio() * 100 if gp and tp else 0)
            if best is None or score > best["confidence"]:
                best = {"vector_index": int(idx), "table_row": int(ridx), "confidence": round(score, 1), "owner": str(r[owner_field]) if owner_field else None}
        if best:
            results.append(best)
    audit("RECORD_LINK", f"{vector_path.name} ↔ {table_path.name}", "Completed", rows=len(results))
    return {"ok": True, "mapping": mapping_fields, "linked": results[:500]}


@app.post("/api/change-detection")
def change_detection(payload: dict[str, Any]):
    historical = payload.get("historical")
    current = payload.get("current")
    if not historical or not current:
        raise HTTPException(422, "historical and current vector sources are required")
    a = metric_pair(read_vector(safe_path(str(historical))))
    b = metric_pair(read_vector(safe_path(str(current))))
    matches = pair_match(a, b, 500)
    matched_a = {m["a_index"] for m in matches if m["confidence"] >= 60}
    matched_b = {m["b_index"] for m in matches if m["confidence"] >= 60}
    new_structures = [i for i in range(len(b)) if i not in matched_b]
    demolished = [i for i in range(len(a)) if i not in matched_a]
    boundary_changes = [m for m in matches if m["iou"] < 0.75 and m["confidence"] >= 60]
    stable = [m for m in matches if m["iou"] >= 0.75 and m["confidence"] >= 90]
    result = {
        "new_count": len(new_structures), "demolished_count": len(demolished),
        "boundary_change_count": len(boundary_changes), "stable_count": len(stable),
        "matches": matches[:250],
    }
    audit("CHANGE_DETECTION", f"{Path(str(historical)).name} ↔ {Path(str(current)).name}", "Completed")
    return {"ok": True, **result}


@app.post("/api/harmonize")
def harmonize(payload: dict[str, Any]):
    sources = payload.get("sources", [])
    target_crs = payload.get("target_crs")
    inspected = []
    for src in sources:
        try:
            p = safe_path(str(src["path"] if isinstance(src, dict) else src))
            inspected.append({"file": p.name, **inspect_file(p)})
        except Exception as exc:
            inspected.append({"file": str(src), "error": str(exc)})
    result = {
        "ok": True,
        "target_crs": target_crs or "project-configured",
        "stages": ["ingestion", "crs_normalization", "schema_mapping", "topology_repair", "parcel_building_matching", "confidence_scoring", "human_review", "publish"],
        "sources": inspected,
    }
    audit("HARMONIZE", "workspace", "Completed", sources=len(sources))
    return result



@app.get("/api/audit")
def get_audit():
    return {"ok": True, "events": AUDIT[-500:], "count": len(AUDIT)}


@app.get("/api/files/{file_name}")
def download_file(file_name: str):
    from fastapi.responses import FileResponse
    safe_name = Path(file_name).name
    p = DATA_DIR / safe_name
    if not p.exists() or not p.is_file():
        raise HTTPException(404, "Generated file not found")
    return FileResponse(path=p, filename=p.name)


@app.get("/api/geojson")
def geojson_features(path: str, layer: str | None = None, limit: int = 5000):
    p = safe_path(path)
    gdf = read_vector(p, layer)
    gdf = gdf.head(max(1, min(limit, 20000)))
    return {"type": "FeatureCollection", "features": jsonable(json.loads(gdf.to_json())['features']), "count": len(gdf), "crs": gdf.crs.to_string() if gdf.crs else None}


@app.get("/api/postgis/status")
def postgis_status():
    if not POSTGIS_URL or create_engine is None:
        return {"ok": True, "configured": False, "connected": False}
    try:
        engine = create_engine(POSTGIS_URL, pool_pre_ping=True)
        with engine.connect() as conn:
            version = conn.execute(text("SELECT PostGIS_Version()" if True else "SELECT 1")).scalar()
        return {"ok": True, "configured": True, "connected": True, "postgis_version": str(version)}
    except Exception as exc:
        return {"ok": True, "configured": True, "connected": False, "error": str(exc)}


@app.post("/api/postgis/publish")
def postgis_publish(payload: dict[str, Any]):
    if not POSTGIS_URL:
        raise HTTPException(400, "NAKSHA_POSTGIS_URL is not configured")
    if create_engine is None:
        raise HTTPException(500, "SQLAlchemy is required for PostGIS publishing")
    path = safe_path(str(payload.get("source", "")))
    layer = str(payload.get("layer", "harmonized"))
    table = re.sub(r"[^a-zA-Z0-9_]+", "_", str(payload.get("table", "harmonized"))).strip("_").lower() or "harmonized"
    gdf = read_vector(path, payload.get("source_layer"))
    engine = create_engine(POSTGIS_URL, pool_pre_ping=True)
    gdf.to_postgis(table, engine, if_exists="replace", index=False, schema=str(payload.get("schema", "public")))
    audit("POSTGIS_PUBLISH", path.name, "Completed", table=table)
    return {"ok": True, "table": table, "schema": str(payload.get("schema", "public")), "features": len(gdf), "crs": gdf.crs.to_string() if gdf.crs else None}


@app.post("/api/publish")
def publish(payload: dict[str, Any]):
    source = payload.get("source")
    if not source:
        return {"ok": True, "outputs": ["GeoJSON", "Shapefile", "GeoPackage", "WMS", "WFS", "REST API"], "note": "Provide source to materialize exports."}
    gdf = read_vector(safe_path(str(source)), payload.get("layer"))
    stamp = uuid.uuid4().hex
    geojson_path = DATA_DIR / f"{stamp}.geojson"
    gpkg_path = DATA_DIR / f"{stamp}.gpkg"
    shp_dir = DATA_DIR / f"{stamp}_shp"
    shp_dir.mkdir(exist_ok=True)
    gdf.to_file(geojson_path, driver="GeoJSON")
    gdf.to_file(gpkg_path, layer="harmonized", driver="GPKG")
    shp_path = shp_dir / "harmonized.shp"
    gdf.to_file(shp_path, driver="ESRI Shapefile")
    shp_zip = DATA_DIR / f"{stamp}_shapefile.zip"
    with zipfile.ZipFile(shp_zip, "w", zipfile.ZIP_DEFLATED) as zf:
        for part in shp_dir.iterdir():
            zf.write(part, arcname=part.name)
    audit("PUBLISH", Path(str(source)).name, "Completed")
    return {
        "ok": True,
        "files": {
            "geojson": str(geojson_path),
            "gpkg": str(gpkg_path),
            "shapefile_zip": str(shp_zip),
        },
        "download_urls": {
            "geojson": f"/api/files/{geojson_path.name}",
            "gpkg": f"/api/files/{gpkg_path.name}",
            "shapefile_zip": f"/api/files/{shp_zip.name}",
        },
        "services": ["WMS", "WFS", "REST API"]
    }


@app.post("/api/review")
def review(payload: dict[str, Any]):
    action = payload.get("action", "approve")
    record_id = str(payload.get("record_id", "unknown"))
    note = str(payload.get("note", ""))
    audit("HUMAN_REVIEW", record_id, action.upper(), note=note[:1000])
    return {"ok": True, "record_id": record_id, "action": action, "logged": True}


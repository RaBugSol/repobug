# NAKSHA — Real Geospatial System

NAKSHA is a functional demonstrator for automated integration and intelligent harmonization of multi-source urban land data.

## Architecture

- Frontend: single-page HTML + Leaflet interactive map
- API: FastAPI REST service
- Geospatial engine: GDAL/OGR through GeoPandas/Pyogrio, PROJ/pyproj, Shapely, Rasterio
- Optional database: PostgreSQL + PostGIS

## Integrated REST APIs

- `GET /api/health` — service and PostGIS status
- `POST /api/upload` — upload and inspect GIS/raster/tabular data
- `GET /api/inspect?path=...` — inspect an uploaded source
- `GET /api/geojson?path=...` — expose a vector layer as GeoJSON for the interactive map
- `POST /api/transform` — coordinate transformation using PROJ
- `POST /api/match` — IoU + distance + area + attribute spatial matching
- `POST /api/topology/scan` — topology QA
- `POST /api/topology/repair` — geometry repair and GPKG output
- `POST /api/records/map-schema` — revenue-record schema mapping
- `POST /api/records/link` — parcel ↔ revenue record linking
- `POST /api/change-detection` — historical/current comparison
- `POST /api/harmonize` — end-to-end orchestration entry point
- `POST /api/review` — human review decision + audit event
- `GET /api/audit` — audit trail
- `POST /api/publish` — GeoJSON/GPKG/Shapefile export
- `GET /api/files/{file_name}` — download generated files
- `GET /api/postgis/status` — PostGIS connection test
- `POST /api/postgis/publish` — write a harmonized layer into PostGIS

FastAPI also exposes interactive OpenAPI documentation at `/docs` and `/redoc` when the API server is running.

## Run

### Backend

```bash
pip install -r requirements.txt
uvicorn backend:app --host 0.0.0.0 --port 8000
```

### Frontend

Open `index.html` in a browser after starting the backend. The UI defaults to `http://localhost:8000`; change the API base URL in the Settings/local storage if the server is elsewhere.

### PostGIS

```bash
docker compose up -d postgis
```

Then set:

```bash
NAKSHA_POSTGIS_URL=postgresql+psycopg://naksha:naksha@localhost:5432/naksha
```

## Demo data

`data/demo_data/` contains small GeoJSON and CSV examples for parcel matching, change detection and revenue-record linking.

## SIH positioning

The demonstrator is designed to show the complete flow:

`Multi-source data → CRS normalization → schema harmonization → spatial matching → topology QA → confidence scoring → human review → PostGIS/API/export`

It is a technical demonstrator, not a production legal land-record registry. Production deployment would require authentication/authorization, official source authority rules, persistent audit storage, spatial indexing, job queues, security hardening and validation against departmental datasets.

## One-site deployment

NAKSHA is packaged as one web service: FastAPI serves the frontend (`index.html`) and all `/api/*` endpoints from the same origin. Set `PORT` in the hosting platform and start with `uvicorn backend:app --host 0.0.0.0 --port $PORT`.

### Docker

```bash
docker compose up --build
```
Then open `http://localhost:8000`.

### Production notes

- Set `NAKSHA_POSTGIS_URL` to a managed PostgreSQL/PostGIS database URL when deploying without the bundled database.
- Put the service behind HTTPS.
- Configure authentication/authorization before exposing land-record data publicly.
- Persist uploaded data and audit logs on durable storage.
